﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeManager
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            InputPanel.Visibility = Visibility.Visible;
            RecipeListView.Visibility = Visibility.Collapsed;
            DetailsPanel.Visibility = Visibility.Collapsed;
            ClearIngredientFields();
        }

        private void ViewRecipes_Click(object sender, RoutedEventArgs e)
        {
            RecipeListView.ItemsSource = recipes.OrderBy(r => r.Name).ToList();
            RecipeListView.Visibility = Visibility.Visible;
            InputPanel.Visibility = Visibility.Collapsed;
            DetailsPanel.Visibility = Visibility.Collapsed;
        }

        private void ClearRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (recipes.Any())
            {
                recipes.Clear();
                MessageBox.Show("All recipes have been cleared.");
                RecipeListView.ItemsSource = null;
            }
            else
            {
                MessageBox.Show("No recipes to clear.");
            }
        }

        private void SubmitRecipe_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string recipeName = RecipeNameTextBox.Text;

                if (string.IsNullOrWhiteSpace(recipeName))
                {
                    throw new ArgumentException("Recipe name must be filled.");
                }

                List<Ingredient> ingredients = new List<Ingredient>();

                foreach (StackPanel ingredientPanel in IngredientsPanel.Children.OfType<StackPanel>())
                {
                    string ingredientName = ((TextBox)ingredientPanel.Children[1]).Text;
                    if (!int.TryParse(((TextBox)ingredientPanel.Children[3]).Text, out int calories))
                    {
                        throw new FormatException("Calories must be a number.");
                    }
                    string foodGroup = ((ComboBox)ingredientPanel.Children[5]).Text;

                    if (string.IsNullOrWhiteSpace(ingredientName) || string.IsNullOrWhiteSpace(foodGroup))
                    {
                        throw new ArgumentException("All fields must be filled.");
                    }

                    ingredients.Add(new Ingredient
                    {
                        Name = ingredientName,
                        Calories = calories,
                        FoodGroup = foodGroup
                    });
                }

                var existingRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
                if (existingRecipe != null)
                {
                    existingRecipe.Ingredients.AddRange(ingredients);
                }
                else
                {
                    var recipe = new Recipe
                    {
                        Name = recipeName,
                        Ingredients = ingredients
                    };
                    recipes.Add(recipe);
                }

                MessageBox.Show("Recipe added successfully!");
                ClearInputFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BackToMenu_Click(object sender, RoutedEventArgs e)
        {
            InputPanel.Visibility = Visibility.Collapsed;
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            AddIngredientFields();
        }

        private void ClearInputFields()
        {
            RecipeNameTextBox.Text = string.Empty;
            ClearIngredientFields();
        }

        private void ClearIngredientFields()
        {
            IngredientsPanel.Children.Clear();
            AddIngredientFields();
        }

        private void AddIngredientFields()
        {
            StackPanel ingredientPanel = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(0, 5, 0, 5) };

            TextBlock ingredientNameLabel = new TextBlock { Text = "Ingredient Name:", Margin = new Thickness(5) };
            TextBox ingredientNameTextBox = new TextBox { Width = 200, Margin = new Thickness(5) };

            TextBlock caloriesLabel = new TextBlock { Text = "Calories:", Margin = new Thickness(5) };
            TextBox caloriesTextBox = new TextBox { Width = 200, Margin = new Thickness(5) };

            TextBlock foodGroupLabel = new TextBlock { Text = "Food Group:", Margin = new Thickness(5) };
            ComboBox foodGroupComboBox = new ComboBox { Width = 200, Margin = new Thickness(5) };
            foodGroupComboBox.Items.Add("Fat");
            foodGroupComboBox.Items.Add("Vegetables");
            foodGroupComboBox.Items.Add("Protein");
            foodGroupComboBox.Items.Add("Carbohydrates");
            foodGroupComboBox.Items.Add("Fruits");

            ingredientPanel.Children.Add(ingredientNameLabel);
            ingredientPanel.Children.Add(ingredientNameTextBox);
            ingredientPanel.Children.Add(caloriesLabel);
            ingredientPanel.Children.Add(caloriesTextBox);
            ingredientPanel.Children.Add(foodGroupLabel);
            ingredientPanel.Children.Add(foodGroupComboBox);

            IngredientsPanel.Children.Add(ingredientPanel);
        }

        private void RecipeListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RecipeListView.SelectedItem is Recipe selectedRecipe)
            {
                ShowRecipeDetails(selectedRecipe);
            }
        }

        private void ShowRecipeDetails(Recipe recipe)
        {
            var details = $"Recipe Name: {recipe.Name}\n" +
                          $"Ingredients:\n";

            foreach (var ingredient in recipe.Ingredients)
            {
                details += $"- {ingredient.Name}: {ingredient.Calories} calories, {ingredient.FoodGroup}\n";
            }

            details += $"Total Calories: {recipe.Ingredients.Sum(i => i.Calories)}";

            RecipeDetailsTextBlock.Text = details;
            DetailsPanel.Visibility = Visibility.Visible;
            RecipeListView.Visibility = Visibility.Collapsed;
        }

        private void ViewRecipeDetails_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListView.SelectedItem is Recipe selectedRecipe)
            {
                ShowRecipeDetails(selectedRecipe);
            }
            else
            {
                MessageBox.Show("Please select a recipe to view its details.");
            }
        }

        private void BackToRecipes_Click(object sender, RoutedEventArgs e)
        {
            DetailsPanel.Visibility = Visibility.Collapsed;
            RecipeListView.Visibility = Visibility.Visible;
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }
}

