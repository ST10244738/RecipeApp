﻿using System;
using System.Collections.Generic;
using System.Linq;

// Class representing an ingredient
class Ingredient
{
    public string Name { get; set; }
    public int Calories { get; set; }
    public string FoodGroup { get; set; }
}

// Class representing a recipe
class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }

    // Constructor to initialize a recipe with a name
    public Recipe(string name)
    {
        Name = name;
        Ingredients = new List<Ingredient>();
    }

    // Method to calculate the total calories of all ingredients in the recipe
    public int CalculateTotalCalories()
    {
        return Ingredients.Sum(ingredient => ingredient.Calories);
    }
}

// Delegate to handle the notification when a recipe exceeds 300 calories
delegate void RecipeNotification(string recipeName);

// Class managing recipes and user interactions
class RecipeManager
{
    private List<Recipe> recipes = new List<Recipe>();

    // Event to notify the user when a recipe exceeds 300 calories
    public event RecipeNotification RecipeExceedsCalories;

    // Method to add a new recipe
    public void AddRecipe()
    {
        Console.WriteLine("Enter the name of the recipe:");
        string recipeName = Console.ReadLine();

        Recipe recipe = new Recipe(recipeName);

        while (true)
        {
            Console.WriteLine("Enter the name of the ingredient (or type 'done' to finish adding ingredients):");
            string ingredientName = Console.ReadLine();
            if (ingredientName.ToLower() == "done")
                break;

            Ingredient ingredient = new Ingredient { Name = ingredientName };

            // Input validation for calories
            int calories;
            while (true)
            {
                Console.WriteLine("Enter the number of calories for the ingredient:");
                string input = Console.ReadLine();
                if (!int.TryParse(input, out calories))
                {
                    Console.WriteLine("Invalid input! Please enter a valid number for calories.");
                }
                else
                {
                    ingredient.Calories = calories;
                    break;
                }
            }

            Console.WriteLine("Enter the food group for the ingredient:");
            ingredient.FoodGroup = Console.ReadLine();

            recipe.Ingredients.Add(ingredient);
        }

        recipes.Add(recipe);

        // Check if total calories exceed 300 and notify the user
        if (recipe.CalculateTotalCalories() > 300)
        {
            RecipeExceedsCalories?.Invoke(recipe.Name);
        }
    }

    // Method to display all recipes in alphabetical order
    public void DisplayRecipes()
    {
        var sortedRecipes = recipes.OrderBy(recipe => recipe.Name);
        Console.WriteLine("All Recipes:");
        foreach (var recipe in sortedRecipes)
        {
            Console.WriteLine(recipe.Name);
        }
    }

    // Method to select and display a recipe
    public void DisplayRecipeDetails()
    {
        Console.WriteLine("Enter the name of the recipe to display details:");
        string recipeName = Console.ReadLine();

        Recipe selectedRecipe = recipes.FirstOrDefault(recipe => recipe.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

        if (selectedRecipe != null)
        {
            Console.WriteLine($"Ingredients for {selectedRecipe.Name}:");
            foreach (var ingredient in selectedRecipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Name} - {ingredient.Calories} calories - {ingredient.FoodGroup}");
            }

            int totalCalories = selectedRecipe.CalculateTotalCalories();
            Console.WriteLine($"Total calories: {totalCalories}");

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: Total calories exceed 300!");
            }
        }
        else
        {
            Console.WriteLine("Recipe not found!");
        }
    }
}

// Class containing unit tests
class UnitTests
{
    public static void TestTotalCaloriesCalculation()
    {
        // Arrange
        Recipe recipe = new Recipe("Test Recipe");
        recipe.Ingredients.Add(new Ingredient { Name = "Ingredient 1", Calories = 100 });
        recipe.Ingredients.Add(new Ingredient { Name = "Ingredient 2", Calories = 200 });

        // Act
        int totalCalories = recipe.CalculateTotalCalories();

        // Assert
        Console.WriteLine($"Total calories: {totalCalories}");
        if (totalCalories == 300)
        {
            Console.WriteLine("Total calories calculation test passed.");
        }
        else
        {
            Console.WriteLine("Total calories calculation test failed.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        RecipeManager recipeManager = new RecipeManager();

        // Subscribe to RecipeExceedsCalories event
        recipeManager.RecipeExceedsCalories += RecipeExceedsCaloriesHandler;

        while (true)
        {
            Console.WriteLine("\nSelect an option:");
            Console.WriteLine("1. Add Recipe");
            Console.WriteLine("2. Display Recipes");
            Console.WriteLine("3. Display Recipe Details");
            Console.WriteLine("4. Run Unit Test");
            Console.WriteLine("5. Exit");

            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.WriteLine("Invalid input! Please enter a valid number.");
            }

            switch (choice)
            {
                case 1:
                    recipeManager.AddRecipe();
                    break;
                case 2:
                    recipeManager.DisplayRecipes();
                    break;
                case 3:
                    recipeManager.DisplayRecipeDetails();
                    break;
                case 4:
                    UnitTests.TestTotalCaloriesCalculation();
                    break;
                case 5:
                    Console.WriteLine("Exiting...");
                    return;
                default:
                    Console.WriteLine("Invalid choice! Please select a valid option.");
                    break;
            }
        }
    }

    // Event handler for RecipeExceedsCalories event
    static void RecipeExceedsCaloriesHandler(string recipeName)
    {
        Console.WriteLine($"Warning: {recipeName} exceeds 300 calories!");
    }
}


