﻿using System.Windows;


namespace cmcsApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddModule_Click(object sender, RoutedEventArgs e)
        {
            // This could be expanded to add dynamic fields for more modules
            MessageBox.Show("Add Another Module clicked!");
        }

        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // For now, just simulate form submission
            MessageBox.Show("Claim Submitted!");
        }
    }
}
