﻿using System;

namespace RecipeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();
            recipe.GetRecipeDetailsFromUser();
            recipe.DisplayRecipe();

            while (true)
            {
                // displaying the emnu
                Console.WriteLine("\nOptions:");
                Console.WriteLine("1. Scale the recipe");
                Console.WriteLine("2. Reset quantities");
                Console.WriteLine("3. Clear all data and add a new recipe");
                Console.WriteLine("4. Exit");

                Console.Write("Enter your option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    // calling the classes onto the main method
                    case "1":
                        recipe.ScaleRecipe();
                        recipe.DisplayRecipe();
                        break;
                    case "2":
                        recipe.ResetQuantities();
                        recipe.DisplayRecipe();
                        break;
                    case "3":
                        recipe.ClearDataAndEnterNewRecipe();
                        recipe.GetRecipeDetailsFromUser();
                        recipe.DisplayRecipe();
                        break;
                    case "4":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
    }

    // class for recipe
    class Recipe
    {
        private Ingredient[] ingredients;
        private string[] steps;

        public void GetRecipeDetailsFromUser()
        {
            Console.Write("Enter the number of ingredients: ");
            int ingredientCount;
            while (!int.TryParse(Console.ReadLine(), out ingredientCount) || ingredientCount <= 0)
            {
                Console.WriteLine("Please enter a valid positive integer.");
                Console.Write("Enter the number of ingredients: ");
            }
            ingredients = new Ingredient[ingredientCount];

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"\nIngredient {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                double quantity;
                Console.Write("Quantity: ");
                while (!double.TryParse(Console.ReadLine(), out quantity) || quantity <= 0)
                {
                    Console.WriteLine("Please enter a valid positive number.");
                    Console.Write("Quantity: ");
                }
                Console.Write("Unit of Measurement: ");
                string unit = Console.ReadLine();

                ingredients[i] = new Ingredient(name, quantity, unit);
            }
             // steps
            Console.Write("\nEnter the number of steps: ");
            int stepCount;
            while (!int.TryParse(Console.ReadLine(), out stepCount) || stepCount <= 0)
            {
                Console.WriteLine("Please enter a valid positive integer.");
                Console.Write("Enter the number of steps: ");
            }
            steps = new string[stepCount];

            for (int i = 0; i < stepCount; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                steps[i] = Console.ReadLine();
            }
        }

        public void DisplayRecipe()
        {
            // displaying the added recipe
            Console.WriteLine("\nRecipe:");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }

        // creating a reset method for scale recipe
        public void ScaleRecipe()
        {
            Console.Write("\nEnter scaling factor (0.5, 2, or 3): ");
            double factor;
            while (!double.TryParse(Console.ReadLine(), out factor) || (factor != 0.5 && factor != 2 && factor != 3))
            {
                Console.WriteLine("Please enter a valid scaling factor (0.5, 2, or 3).");
                Console.Write("Enter scaling factor: ");
            }

            foreach (var ingredient in ingredients)
            {
                ingredient.ScaleQuantity(factor);
            }
        }

        // creating a reset method for quantities
        public void ResetQuantities()
        {
            foreach (var ingredient in ingredients)
            {
                ingredient.ResetQuantity();
            }
        }

        public void ClearDataAndEnterNewRecipe()
        {
            ingredients = null;
            steps = null;
        }
    }

    // calss for ingrediets
    class Ingredient
    {
        public string Name { get; }
        public double OriginalQuantity { get; }
        public string Unit { get; }
        public double Quantity { get; private set; }

        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            OriginalQuantity = quantity;
            Quantity = quantity;
            Unit = unit;
        }

        public void ScaleQuantity(double factor)
        {
            Quantity *= factor;
        }

        public void ResetQuantity()
        {
            Quantity = OriginalQuantity;
        }
    }
}